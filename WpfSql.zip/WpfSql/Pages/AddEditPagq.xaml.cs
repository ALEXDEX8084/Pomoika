﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfSql.Classes;

namespace WpfSql.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private Person _currentperson = new Person(); //экземпляр добавляемого пользователя
        public AddEditPagq()
        {
            DGridUsers = _currentperson;
            InitializeComponent();
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentperson.FirstName))
                error.AppendLine("Укажите имя");
            if(string.IsNullOrWhiteSpace(_currentperson.LastName))
                error.AppendLine("Укажите Фамилию");
            if(string.IsNullOrWhiteSpace((_currentperson.Age))
                (error.AppendLine("Укажите возраст")));

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            StarodubcevEntities.GetContext().Person.Add(_currentperson);
                try
            {

                StarodubcevEntities.GetContext().SaveChanges();
                MessageBox.Show("Пользователь добавлен");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

    }
    
