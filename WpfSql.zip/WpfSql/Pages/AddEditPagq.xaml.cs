﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfSql.Classes;

namespace WpfSql.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private Person _currentperson = new Person(); //экземпляр добавляемого пользователя
        public AddEditPagq(Person selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.FirstName))
                error.AppendLine("Укажите имя");
            if(string.IsNullOrWhiteSpace(_currentperson.LastName))
                error.AppendLine("Укажите Фамилию");
            if(string.IsNullOrWhiteSpace(age.Text))
                error.AppendLine("Укажите возраст");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if(_currentperson.ID == 0)
            StarodubcevEntities.GetContext().Person.Add(_currentperson);//Добавить в контекст
                try
            {

                StarodubcevEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

    }
    
