products = list()
check_no = 1


def add_item(item_name, item_cost):
    global products
    products.append([item_name, item_cost])


def print_receipt():
    global check_no, products
    if len(products) == 0:
        raise "Нет товара в чеке!"
    print(f"Чек {check_no}. Всего предметов: {len(products)}")
    summa = 0
    for i in range(len(products)):
        print(products[i][0], '-', products[i][1])
        summa += products[i][1]
    print("Итог:", summa)
    print("-----")
    check_no += 1
    products.clear()


add_item('Блокнот', 100)
print_receipt()

add_item('Ручка', 70)
print_receipt()
