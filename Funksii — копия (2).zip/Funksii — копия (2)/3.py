ok = ""


def print_without_duplicates(message):
    global ok
    if message != ok:
        print(message)
        ok = message

print_without_duplicates("Привет")
print_without_duplicates("Не могу до тебя дозвониться")
print_without_duplicates("Не могу до тебя дозвониться")
print_without_duplicates("Не могу до тебя дозвониться")
print_without_duplicates("Когда доедешь до дома")
print_without_duplicates("Ага, жду")
print_without_duplicates("Ага, жду")
print_without_duplicates("Не могу до тебя дозвониться")