﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZakazVKFC
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ChickenBurgerCount.IsEnabled = false;
            ChickenWingsCount.IsEnabled = false;
            SouseCount.IsEnabled = false;
            CoffeCount.IsEnabled = false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            lstbox.Items.Clear();
            lstbox.Items.Add($"{DateTime.Now}");
            lstbox.Items.Add("Заказ:");
            int a = 0, b = 0, c = 0, d = 0;
            if(ChickenBurgerCheck.IsChecked == true)
            {
                ChickenBurgerCount.IsEnabled = true;
                a = int.Parse(ChickenBurgerCount.Text) * 100;
                lstbox.Items.Add($"Бургер {ChickenBurgerCount.Text} * 100 руб. ={a}");

            }
            if(ChickenWingsCheck.IsChecked == true)
            {
                ChickenWingsCount.IsEnabled = true;
                b = int.Parse(ChickenWingsCount.Text) * 280;
                lstbox.Items.Add($"Картошка фри {ChickenWingsCount.Text} * 280 руб. = {b}  руб.");
            }
            if (SouseCheck.IsChecked == true)
            {
                SouseCount.IsEnabled = true;
                c = int.Parse(SouseCount.Text) * 50;
                lstbox.Items.Add($"Соус {SouseCount.Text} * 50 руб. = {c} руб.");

            }
            if (CoffeCheck.IsChecked == true)
            {
                CoffeCount.IsEnabled = true;
                d = int.Parse(CoffeCount.Text) * 100;
                lstbox.Items.Add($"Кофе {CoffeCount.Text} * 100 руб. = {d} руб.");

            }
            lstbox.Items.Add("-------------------");
            lstbox.Items.Add($"К оплате: {a + b + c + d} ");
        }

        private void ChickenBurgerCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (ChickenBurgerCheck.IsChecked == true)
            {
                ChickenBurgerCount.IsEnabled = true;
            }
        }

        private void ChickenWingsCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (ChickenWingsCheck.IsChecked == true)
            {
                ChickenWingsCount.IsEnabled = true;
            }
        }

        private void SouseCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (SouseCheck.IsChecked == true)
            {
                SouseCount.IsEnabled = true;
            }
        }

        private void CoffeCheck_Checked(object sender, RoutedEventArgs e)
        {
            if (CoffeCheck.IsChecked == true)
            {
                CoffeCount.IsEnabled = true;
            }
        }
    }
}
