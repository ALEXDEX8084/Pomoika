def average(values):



print(average([1, 2, 3, 4, 5]))