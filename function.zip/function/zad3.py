def from_string_to_list(s, numbers):
    numbers += [int(el) for el in s.split()]


a = [1, 2, 3]
from_string_to_list("1 3 99 52", a)
print(*a)
