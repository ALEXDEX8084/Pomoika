def num_digits(number):
    k = 0
    while number % 10:
        k += 1
        number //= 10
    return k


print(num_digits(54356))