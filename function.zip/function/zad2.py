def count_food(days):
    s = 0
    for day in days:
        s += daily_food[day - 1]
    return s


daily_food = [0, 150, 150]
print((count_food([1])))
