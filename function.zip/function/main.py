brain = list()


def parrot(phrase):
    if phrase not in brain:
        brain.append(phrase)
    else:
        print(phrase)


parrot("Привет!")
parrot("Как тебя зовут?")
parrot("Привет!")
parrot("Как дела?")
parrot("Как тебя зовут?")
